package com.example.paranoidandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Temperatures extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temperatures);
    }
}
